#include "Cconta.h"


CConta::CConta(int a)
{
  numero = a;
};
