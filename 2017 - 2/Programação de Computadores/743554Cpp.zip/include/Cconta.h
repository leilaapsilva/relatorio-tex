
 class CConta
{

  int numero;
  public:
    CConta();
    CConta(int a);

};
