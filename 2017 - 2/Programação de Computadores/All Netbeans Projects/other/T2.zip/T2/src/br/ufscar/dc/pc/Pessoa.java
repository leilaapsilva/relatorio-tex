package br.ufscar.dc.pc;

public class Pessoa {
    
    private String nome;
    private int idade;
    private AnimalDomestico animal;
    
    public Pessoa(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public AnimalDomestico getAnimal() {
        return animal;
    }

    public void setAnimal(AnimalDomestico animal) {
        this.animal = animal;
    }
    
    public void imprime() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        if (animal != null) {
            animal.imprime();
        } else {
            System.out.println("Não há animal associado");
        }
    }        
}
