package br.ufscar.dc.pc;

public class AnimalDomestico {
    
    private String nome;
    private int peso;
    private Pessoa dono;

    public AnimalDomestico(String nome, int peso, Pessoa dono) {
        this.nome = nome;
        this.peso = peso;
        this.dono = dono;
        this.dono.setAnimal(this);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public Pessoa getDono() {
        return dono;
    }

    public void setDono(Pessoa dono) {
        this.dono = dono;
    }
    
    public void imprime() {
        System.out.println("Nome: " + nome);
        System.out.println("Peso: " + peso);
    }
}
