package br.ufscar.dc.pc;

public class Peixe extends AnimalDomestico{
    
    private String tipoHabitat;

    public Peixe(String nome, int peso, Pessoa dono, String tipoHabitat) {
        super(nome, peso, dono);
        this.tipoHabitat = tipoHabitat;
    }

    @Override
    public void imprime() {
        super.imprime();
        System.out.println("Habitat : " + tipoHabitat);
    }
    
}
