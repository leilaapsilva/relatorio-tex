package br.ufscar.dc.pc;

public class Cachorro extends AnimalDomestico{
    
    private String raca;

    public Cachorro(String nome, int peso, Pessoa dono, String raca) {
        super(nome, peso, dono);
        this.raca = raca;
    }

    @Override
    public void imprime() {
        super.imprime();
        System.out.println("Raça : " + raca);
    }
    
}
