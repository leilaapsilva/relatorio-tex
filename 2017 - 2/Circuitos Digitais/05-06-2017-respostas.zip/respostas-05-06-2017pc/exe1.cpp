#include <iostream>

using namespace std;

int main(){
	double a, b;
	cin >> a >> b;

	cout << "a soma: " << a+b << endl;
	cout << "o produto: "<< a*b << endl;
	cout << "o quociente: " << a/b << " ou " << b/a << endl;

	return 0;
}