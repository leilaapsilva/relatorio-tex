#include <iostream>

using namespace std;
// teve erro de digitação (na vdd essa questão era pra ser a 5 .-.)
int main(){
	cout << endl << "teve erro de digitação (na vdd essa questão era pra ser a 5 .-.)" << endl 
	<< "(algum estagiario vai ser demitido)" << endl 
	<< "perd40 p3l0 v4c1l0 n40 f01 pr0p05174l m45 v4 1c0n71nu4r 4c0n73c3nd0" << endl << endl;
	return 0;
}