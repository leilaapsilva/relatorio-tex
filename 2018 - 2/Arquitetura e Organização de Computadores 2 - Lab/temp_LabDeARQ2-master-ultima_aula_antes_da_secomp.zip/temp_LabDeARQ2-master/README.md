# temp_LabDeARQ2
salvando arquivos pq a maquina virtual da oracle me odeia
hg
