Arquivo zip gerado em: 16/12/2018 13:37:50 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Black Friday