import React from 'react';

const ShowArchived=()=>(
	<div class="checkbox-container">
		  <input type="checkbox" />
		  <span>Exibir Arquivados</span>
	</div>
)

export default ShowArchived;
