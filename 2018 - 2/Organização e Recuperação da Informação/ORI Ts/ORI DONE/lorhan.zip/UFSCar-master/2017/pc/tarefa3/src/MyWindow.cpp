#include "MyWindow.h"

MyWindow::MyWindow( void ) {
    resize( 300, 200 );
    set_title( "Tarefa 3 de PC" );
    add( area );
    area.show();
}
