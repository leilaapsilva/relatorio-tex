#include "../include/includes.h"

void setPos(pair* p, int first, int second){
		p->x = first;
		p->y = second;
}

void setAllPosition(pair *p){
	setPos(&p[0], 10, 530);
	setPos(&p[1], 10, 465);
	setPos(&p[2], 10, 400);
	setPos(&p[3], 10, 325);
	setPos(&p[4], 140, 325);
	setPos(&p[5], 270, 325);
	setPos(&p[6], 270, 256);
	setPos(&p[7], 270, 200);
	setPos(&p[8], 140, 200);
	setPos(&p[9], 10, 200);
	setPos(&p[10], 10, 135);
	setPos(&p[11], 10, 65);
	setPos(&p[12], 10, 0);
	setPos(&p[13], 140, 0);
	setPos(&p[14], 270, 0);
	setPos(&p[15], 405, 0);
	setPos(&p[16], 530, 0);
	setPos(&p[17], 530, 65);
	setPos(&p[18], 530, 135);
	setPos(&p[19], 530, 200);
	setPos(&p[20], 530, 255);
	setPos(&p[21], 530, 325);
	setPos(&p[22], 530, 400);
	setPos(&p[23], 670, 400);
	setPos(&p[24], 795, 400);
	setPos(&p[25], 930, 400);
	setPos(&p[26], 1045, 400);
	setPos(&p[27], 1045, 325);
	setPos(&p[28], 1045, 255);
	setPos(&p[29], 1045, 200);
	setPos(&p[30], 1045, 135);
	setPos(&p[31], 1045, 65);
	setPos(&p[32], 1045, 0);
	setPos(&p[33], 930, 0);
	setPos(&p[34], 795, 0);
	setPos(&p[35], 795, 65);
	setPos(&p[36], 795, 135);
	setPos(&p[37], 795, 200);
	setPos(&p[38], 795, 255);
}

