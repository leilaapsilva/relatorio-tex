#include "includes.h"

int main(){
	Initializers();
	FirstMenu();

	return 0;
}