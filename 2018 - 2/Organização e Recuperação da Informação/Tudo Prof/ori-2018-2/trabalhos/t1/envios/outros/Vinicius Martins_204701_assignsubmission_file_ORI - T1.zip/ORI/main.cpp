#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <math.h>
#include <cstring>
#include <sstream>

#define TAMANHO_HEADER    30             // Tamanho do Header dos arquivo de dados
#define TAMANHO_BLOCO     510            // Tamanho do bloco

#define ARQUIVO_INDEX      "index.txt"

using namespace std;


int quantidadeRegistros;
string nomeArquivo;
const char *filename;

typedef struct CabecalhoArquivo {        // Estrutura para o cabe�alho do arquivo de dados
	int ultimo_rrn_bloco;                // �ltimo bloco utilizado
	int tamanho_arquivo;                 // Quantidade de registros v�lidos
	int prox_rrn_livre;                  // RRN para o pr�ximo bloco com registros livres para grava��o
} CabecalhoArquivo;

typedef struct Registro {              // Estrutura para cada registro de dados
    int RA, anoIngresso;	   // Chave do registro
	char nome[40], Sigla[10];          // Nome                                         |
	char null;                         // Controle de registro | Deletedo: 0; Ativo: 1 |
} Registro;

typedef struct Bloco {              // Estrutura para cada bloco de registros
	 int prox_rrn_livre;			// RRN para o pr�ximo bloco com registros livres para grava��o
	Registro regs[200];             // Quantidade de registros fict�cia
} Bloco;

typedef struct IndexCabecalho {				// Estrutra para o cabe�alho do arquivo de index
	 int count;								// Total de index contidos no arquivo
} IndexCabecalho;

typedef struct Index {				// Estrutura para cada index
	 int chave;				// Chave prim�ria, RA
	 int rrn;						// RRN para o bloco do registro
} Index;


FILE *base_de_dados;                     // Ponteiro para o arquivo de dados
FILE *_index;			                 // Ponteiro para o arquivo de index
CabecalhoArquivo *_buffer_cabecalho;     // Define o buffer do header do arquivo de dados
IndexCabecalho *_buffer_index_cabecalho; // Define o buffer do header do arquivo de index
Index *_buffer_index;                    // Define o buffer dos de index
int _inicializado = 0;                   // Verifica se o arquivo foi carregado

									   /*
									   *  Atualiza o arquivo de dados com o cabe�alho atualizado
									   */
void atualizaBufferCabecalho() {
	fseek(base_de_dados, 0, SEEK_SET);                                    // Move o ponteiro do arquivo para o inicio
	fwrite(_buffer_cabecalho, 1, sizeof(struct CabecalhoArquivo), base_de_dados);  // Atualiza o header do arquivo de acordo com o buffer
	rewind(base_de_dados);                                                // Atualiza o arquivo no disco
}

/*
*  Posiciona o curso do arquivo de dados no inicio no pr�ximo bloco
*    com espa�o dispon�vel, controlando o aproveitamento de espa�o
*/
int setInicioBlocoAtual() {
	if (_buffer_cabecalho->prox_rrn_livre > 0) {                                     // Caso houve alguma remo��o e ainda tenha espa�o para reaproveitar
		fseek(base_de_dados, TAMANHO_BLOCO * _buffer_cabecalho->prox_rrn_livre, SEEK_SET); // Aponta o ponteiro para o bloco com espa�o
		return _buffer_cabecalho->prox_rrn_livre;                                   // retorno o RRN do bloco
	}
	else {                                                                      // Caso contr�rio aponta para o �ltimo bloco
		fseek(base_de_dados, TAMANHO_BLOCO * _buffer_cabecalho->ultimo_rrn_bloco, SEEK_SET);// Aponta o ponteiro para o �ltimo bloco
		return _buffer_cabecalho->ultimo_rrn_bloco;                                  // retorna o RRN do block
	}
}

/*
*  Posiciona o curso do arquivo de dados em um dados RRN de bloco
*/
void setBlockRRN(int rrn) {
	fseek(base_de_dados, rrn * TAMANHO_BLOCO, SEEK_SET);                                // Posiciona o ponteiro de acordo com o RRN informado
}

/*
*  Atualiza o header do arquivo de index
*/
void atualiza_Buffer_Index() {
	fseek(_index, 0, SEEK_SET);														 // Aponta para o inicio do arquivo do index
	fwrite(_buffer_index_cabecalho, 1, sizeof(struct IndexCabecalho), _index);       // Salva o buffer do header no arquivo
	rewind(_index);                                                                  // Atualiza o arquivo no disco
}

/*
*  Atualiza o arquivo de index com os dados do buffer
*/
void atualiza_Index() {
	fseek(_index, sizeof(struct IndexCabecalho), SEEK_SET);                                      // Movo o ponteiro para o incio da �rea de dados do arquivo
	fwrite(_buffer_index, 1, sizeof(struct Index) * _buffer_index_cabecalho->count, _index);     // Atualiza o arquivo de index de acordo com o buffer
	rewind(_index);																				 // Atualiza o arquivo no disco
}



/*
*  Inicializa os arquivos de index e de dados inicializando os seus respectivos Header
*/
int inicializa() {

	base_de_dados = fopen(filename, "w+b");                  // Deve ser um arquivo bin�rio de escrita e leitura
	_index = fopen(ARQUIVO_INDEX, "w+b");                     // Deve ser um arquivo bin�rio de escrita e leitura
	if (base_de_dados == NULL || _index == NULL) {                // Verifica se os arquivos n�o foram criados
		_inicializado = 0;                                     // Seta a vari�vel de controle como n�o inicializada
		fclose(base_de_dados);                                    // Fecha o arquivo
		fclose(_index);                                       // Fecha o arquivo
		return -1;                                            // Retorna -1 para indicar que a opera��o n�o ocorreu com sucesso
	}

	_buffer_cabecalho = ( struct CabecalhoArquivo * )malloc(sizeof(struct CabecalhoArquivo));       // Cria o buffer do header do arquivo de dados
	_buffer_cabecalho->ultimo_rrn_bloco = 1;                      // Inicia a contagem dos blocos a partir do RRN 1, pois o 0 � para o Header
	_buffer_cabecalho->tamanho_arquivo = 0;                      // Inicia a contagem de registros ativos em 0
	_buffer_cabecalho->prox_rrn_livre = -1;                     // Inicia com -1 para indicar que n�o tem blocos para reaproveitamento

	atualizaBufferCabecalho();                                     // Atualiza o header do arquivo com base no buffer

	Bloco *block = ( struct Bloco * )calloc(1, sizeof(struct Bloco));           // Cria um novo bloco de registros na inicializa��o

	setInicioBlocoAtual();                                   // Posiciona o ponteiro do arquivo para o pr�ximo bloco dispon�vel
	fwrite(block, 1, TAMANHO_BLOCO, base_de_dados);                  // Escreve o bloco inicializado no arquivo
	rewind(base_de_dados);                                        // Atualiza o arquivo no disco

	_buffer_index_cabecalho =( struct IndexCabecalho * ) malloc(sizeof(struct IndexCabecalho));// Inicializa o buffer do header do index
	_buffer_index_cabecalho->count = 0;                          // Inicia a contagem em 0

	free(block);                                              // Elimana o bloco vazio criado da mem�ria
	return _inicializado = 1;                                  // retorna 1 para indicar que tudo est� ok
}

/*
*  Busca bin�ria no arquivo de index para localizar um determinado index com base na chave informada
*/
int search(int key, int begin, int end) {

	if (_buffer_index_cabecalho->count == 0)                  // Caso seja o primeiro index
		return -1;

	int div = ceil(((double)end - begin) / 2);             // Calcula a posi��o central do bloco que vai ser percorrido

	int currentKey;

	 currentKey = (_buffer_index + (begin + div))->chave; // Captura no buffer de index a chave na posi��o central
														   //printf("DEBUG || Current Key %i | div %i | begin %i | end %i | teste %f\n", currentKey, div, begin, end, ((double)1/2));
	if (currentKey == key)                                 // Verifica se � a chave procurada
		return (div + begin);                              // Retorna a posi��o da chave atual
	else if (begin >= end)                                 // Caso busca termine
		return -1;                                         // Retorna -1 para indicar que a busca n�o encontrou
	else {                                                 // Caso a busca deva continuar
		if (currentKey > key)                              // Caso a chave atual seja maior que a chave pesquisada
			return search(key, begin, (begin + end) / 2);      // Avan�a para a esquerda
		else                                               // Caso a chave atual seja menor que a chave pesquisada
			return search(key, end - ((end - begin) / 2), end); // Avan�a para a direita
	}
	return -1;                                             // Retorna -1 para indicar que a busca n�o finalizou
}

/*
*  Busca um registro com base na chave informada
*/
int encontraRegistro(int key, Registro *reg) {

	int posicao = search(key, 0, _buffer_index_cabecalho->count - 1);

	if (posicao < 0) return -1;

	setBlockRRN((_buffer_index + posicao)->rrn);
	Bloco *block = ( struct Bloco * )malloc(sizeof(struct Bloco));
	fread(block, 1, TAMANHO_BLOCO, base_de_dados);

	for (int i = 0; i<quantidadeRegistros; i++) {

		if (block->regs[i].null == 1 && block->regs[i].RA == key) {
			//printf("NULL: %i\n", block->regs[i].null);
			memcpy(reg, &block->regs[i], sizeof(struct Registro));
			return 1;
		}
	}
	return -1;
}

/*
*  Captura a posi��o no buffer de index onde um novo index deve ser inserido j� ordenado
*/
int get_Posicao_Insercao(int key, int comeco, int fim) {

	if (_buffer_index_cabecalho->count == 0)                             // Caso seja o primeiro index
		return 0;                                                     // Retorna a posi��o zero

	int div = ceil(((double)fim - comeco) / 2);                        // Calcula o posi��o central da lista

	int currentKey = (_buffer_index + (comeco + div))->chave;            // Captura o valor da chave central
																	  //printf("DEBUG || Current Key %i | div %i | begin %i | end %i | teste %f\n", currentKey, div, begin, end, ((double)1/2));

	if (currentKey == key)                                            // Se a chave atual for a chave procurada
		return -3;                                                    // -3 Index j� inserido
	else if (comeco >= fim)                                            // Caso toda lista sej� percorrida
		return comeco;                                                 // Retorna ultima posi��o pesquisada
	else {                                                            // Se a chave atual for diferente da chave procurada
		if (currentKey > key)                                         // Caso a chave atual for maior que a procurada
			return get_Posicao_Insercao(key, comeco, (comeco + fim) / 2);
		else                                                          // Caso a chave atual for maior que a procurada
			return get_Posicao_Insercao(key, fim - ((fim - comeco) / 2), fim);
	}
	return -4;                                                        // Fim da execu��o sem resultado
}

/*
*  Insere um novo index no buffer de index e no arquivo de index
*/
int inserirIndex(Index *novoIndex) {
	int posicao;                                                                         // Posi��o onde o index deve ser inserido
	Index *temp = ( struct Index * )malloc(sizeof(struct Index) * (_buffer_index_cabecalho->count + 1));      // Temp para a lista Index com mais espa�o
	posicao = get_Posicao_Insercao(novoIndex->chave, 0, _buffer_index_cabecalho->count - 1);     // Captura a posi��o onde o index deve ser ins.

	if (posicao < 0) return -1;                                                          // Posi��o negativa, a lista ta vazia

	if (_buffer_index_cabecalho->count > 0 && novoIndex->chave > (_buffer_index + posicao)->chave) // Inserir a esquerda ou a diretira
		posicao++;                                                                       // Caso for a direita, incrementa a posi��o

	int tamanhoComeco = sizeof(struct Index) * posicao;                                      // Calcula o tamanho a esquerda
	int tamanhoEnd = sizeof(struct Index) * (_buffer_index_cabecalho->count - posicao);     // Calcula o tamanho a direita

	memcpy(temp, _buffer_index, tamanhoComeco);                                              // Copia para temp a parte da esquerada
	memcpy(temp + posicao, novoIndex, sizeof(struct Index));                              // Inseri o novo index
	memcpy(temp + posicao + 1, _buffer_index + posicao, tamanhoEnd);                        // Copia para temp a parte da direita

	_buffer_index_cabecalho->count++;                                                       // Atualiza o Header do index

	free(_buffer_index);                                                                 // Limpa o buffer atual dos index
	_buffer_index =(struct Index*) malloc(sizeof(struct Index) * (_buffer_index_cabecalho->count));        // Recalcula o tamanho da lista de index
	memcpy(_buffer_index, temp, sizeof(struct Index) * _buffer_index_cabecalho->count);     // Atualiza o buffer com a nova lista

	atualiza_Buffer_Index();                                                                 // Atualiza o Header do Index
	atualiza_Index();                                                                       // Atualiza o Index
	return 1;
}

/*
*  Insere um novo registro no arquivo de dados
*/
int inserir(Registro *reg) {

	if (!_inicializado) return -1;                                     // Verifica se os arquivos foram carregados

	Bloco *block =(struct Bloco*) malloc(sizeof(struct Bloco));                     // Cria um bloco na mem�ria prim�ria

	int RRN_atual = setInicioBlocoAtual();                         // Desloca at� o �ltimo bloco utilizado
	fread(block, 1, TAMANHO_BLOCO, base_de_dados);                          // Carrega o �ltimo bloco utilizado na mem�ria principal
	setInicioBlocoAtual();                                          // Desloca at� o inicio do �ltimo bloco novamente

	for (int i = 0; i<quantidadeRegistros; i++) {                               // Percorre pelos registros do bloco atual

		if (block->regs[i].null == 0) {                               // Verifica se o espe�o atual do bloco est� dispon�vel

			Index *index = (struct Index*)malloc(sizeof(struct Index));             // Cria o Index do registro que esta sendo inserido
			//strcpy (index->chave,reg->RA);
			index->chave = reg->RA;                                   // Armazena a chave do registro que esta sendo inserido
			index->rrn = _buffer_cabecalho->ultimo_rrn_bloco;             // Armazena no Index o RRN do bloco corrente

			if (inserirIndex(index) < 0) {                             // Insere o index do novo registro e verif. se esta ok
				free(index);
				free(block);
				return -1;
			}
			reg->null = 1;                                           // Ativa o registro antes de inserir
			memcpy(block->regs + i, reg, sizeof(struct Registro));     // Copia o registro inserido para o bloco onde sera salvo

																	   // Verifica se � o �ltimo registro do bloco e o ult. bloco � o bloco corrente
			if (i == (quantidadeRegistros - 1) && _buffer_cabecalho->ultimo_rrn_bloco == RRN_atual) {

				if (_buffer_cabecalho->prox_rrn_livre == RRN_atual) {
					_buffer_cabecalho->prox_rrn_livre = block->prox_rrn_livre;
					block->prox_rrn_livre = 0;
				}

				fwrite(block, 1, TAMANHO_BLOCO, base_de_dados);             // Atualiza o bloco de dados no arquivo
				_buffer_cabecalho->ultimo_rrn_bloco++;                    // Caso o bloco for preenchido com o m�ximo de registros
				Bloco *nullBlock = (struct Bloco*)calloc(1, sizeof(struct Bloco));  // Cria um novo block v�zio para as pr�ximas inser��es
				fwrite(nullBlock, 1, TAMANHO_BLOCO, base_de_dados);         // Grava o novo bloco v�zio no arquivo
				free(nullBlock);                                     // Limpa a mem�ria removendo o nullBlock
			}
			else if (i == (quantidadeRegistros - 1)) {
				_buffer_cabecalho->prox_rrn_livre = block->prox_rrn_livre;
				block->prox_rrn_livre = 0;
				fwrite(block, 1, TAMANHO_BLOCO, base_de_dados);             // Atualiza o bloco de dados no arquivo
			}
			else {
				fwrite(block, 1, TAMANHO_BLOCO, base_de_dados);             // Atualiza o bloco de dados no arquivo
			}
			_buffer_cabecalho->tamanho_arquivo++;                         // Incrementa a quantidade de registros ativos na base
			atualizaBufferCabecalho();                                    // Atualiza o Header do arquivo de dados
			free(index);                                             // Limpa a mem�ria removendo o index
			break;                                                   // Finaliza a execu��o do for
		}
	}
	free(block);                                                     // Limpa a mem�ria removendo o block
	return 1;
}

void clearDisplay() {
	for (int i = 0; i < 40; i++)
		printf("\n");
}

int main() {
	int control = 1;
	char confirm;
	Registro *reg =(struct Registro*) malloc(sizeof(struct Registro));
	int i = 1;
	string chavepesquisa;


	printf("      PROJETO ORI - MANIPULA��O DE ARQUIVOS \n");
	printf("      INSIRA O NOME DO ARQUIVO \n");
	cin >> nomeArquivo;
	printf("      INSIRA A QUANTIDADE DE REGISTROS \n");
	scanf ("%d", &quantidadeRegistros);
	clearDisplay();

	filename = nomeArquivo.c_str();

	inicializa();



	while (i <= quantidadeRegistros) {
		printf("DIGITE O RA\n");
		cin >> reg->RA;
		printf("DIGITE O NOME\n");
		cin >> reg->nome;
		printf("DIGITE A SILGA DO CURSO\n");
		cin >> reg->Sigla;
		printf("DIGITE O ANO DE INGRESSO\n");
		cin >> reg->anoIngresso;
        fflush(stdin);
		inserir(reg);
		clearDisplay();
		i++;
	}


	printf("   BUSCAR UM REGISTRO\n");
	printf("--------------------------------------------------\n");
	printf("Digite as chaves ou 0 para finalizar as consultas: ");
	cin >> chavepesquisa;

	int chavepesquisaInt;

	stringstream geek(chavepesquisa);
	geek >> chavepesquisaInt;

	while (chavepesquisaInt!=0){
		if (encontraRegistro(chavepesquisaInt, reg) > 0)
			printf(" %d:%s:%s:%d\n", reg->RA, reg->nome, reg->Sigla, reg->anoIngresso);
		else
			printf("Registro nao localizado..");

		cin >> chavepesquisa;
		stringstream geek(chavepesquisa);
        geek >> chavepesquisaInt;
	}

	fclose(base_de_dados);
	fclose(_index);
	return 1;
}

