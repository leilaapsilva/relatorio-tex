#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <string>
#include <string.h>
#include <fstream>

using namespace std;

#define TAM 512 		// TAMANHO M�XIMO DE CADA BLOCO

//Struct que guarda cada campo do registro
struct registro {
	
	string RA, nome, curso, ano;
	
};

int main(int argc, char *argv[]) {
	
	// DECLARA��ES DE VARIAVEIS
	char v [TAM];			
	string arq, pesquisa;
	int n, i, tamRA= 0, tamNome= 0, tamCurso= 0, tamAno = 0, tamVetor = 0, tamReg = 0,j,k,l,m,o,p,r,s;
	j=0;
	
	cin >> arq;			//ENTRADA COM O NOME DO ARQUIVO DE DADOS A SER CRIADO
	cin >> n;			//ENTRADA COM O NUMERO DE REGISTROS
	
	registro* reg = new registro[n]; 		//PARA UTILIZACAO DO VETOR DINAMICO
	
	ofstream dat;		//CRIACAO DO OBJETO PARA O ARQUIVO - variavel do programa (tipo ofstream/saida = informacao saindo do sistema e indo para o arquivo)
	dat.open((arq + ".dat").c_str(), ios::binary);		//ABERTURA DO ARQUIVO (associacao fisica ao arquivo externo)
	
	
	
	for (i=0;i<n;i++){						//LOOP QUE CONTROLA O NUMERO DE REGISTROS A SEREM ADICIONADOS 					
		
		cin >> reg[i].RA;				//LEITURA DO RA
		cin.ignore();			//resolve o problema da quebra de linha quando utilizamos a funcao getline, onde \n pode ser considerado na proxima
								//entrada ja como o final do conjunto de caracteres e assim pulando para a proxima, ficando sem preenchimento de um campo
		getline(cin, reg[i].nome); 	//FUNCAO QUE PERMITE O USO DE ESPACOS E TABULACOES, NAO CONSIDERANDO OS MESMOS COMO FINAL DE ENTRADA DO CAMPO 
		
		cin >> reg[i].curso;			//LEITURA DO CURSO

		cin >> reg[i].ano;				//LEITURA DO ANO DE INGRESSO 
		
		//FUNCOES QUE CALCULAM O TAMANHO DE CADA CAMPO DE UM REGISTRO
		tamRA = (reg[i].RA).size();
		tamNome = (reg[i].nome).size();
		tamCurso = (reg[i].curso).size();
		tamAno = (reg[i].ano).size();
		tamReg = tamRA + tamNome + tamCurso + tamAno;
		
		if (tamReg + tamVetor + 5 <= TAM-2) {	//CHECA SE REGISTRO DIGITADO CABE COMPLETO DENTRO DO VETOR 
		
		for (o=0;o<tamRA; o++, j++){		//LOOP PARA ALOCAR O RA NO BLOCO
			v[j] = reg[i].RA[o];
		}


		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO
	
		for (k=0; k<tamNome; k++, j++){		//LOOP PARA ALOCAR O NOME NO BLOCO
			v[j] = reg[i].nome[k];
		}
		
		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO
		
		for (l=0; l<tamCurso; j++, l++){	//LOOP PARA ALOCAR O CURSO NO BLOCO
			v[j] = reg[i].curso[l];
		}

		
		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO
		
		for (m=0; m<tamAno; j++, m++){		//LOOP PARA ALOCAR O ANO DE INGRESSO NO BLOCO
			v[j] = reg[i].ano[m];

		}
		
		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO

		tamVetor = j;						//SALVA O TAMANHO DO BLOCO NO tamVetor
		
		/*for (p=0; p<j;p++){
			cout<< v[p];
		}
		*/
		v[++j] = (char) 10;					//DIVISAO DE REGISTROS DO BLOCO 
		cout << endl;			
							
	}
	else {
			//Tamanho do vetor, dividindo por 256 e colocando o quociente na penultima posicao do vetor e o resto na ultima
			s = (int(j/256));
			r = (j%256);
			v[510]=r;
			v[511]=s;
			
			
			dat.write(v,512);					//ESCREVE O VETOR NO ARQUIVO

					
			for (o=0;o<tamRA; o++, j++){		//LOOP PARA ALOCAR O RA NO BLOCO
			v[j] = reg[i].RA[o];
		}


		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO
	
		for (k=0; k<tamNome; k++, j++){		//LOOP PARA ALOCAR O NOME NO BLOCO
			v[j] = reg[i].nome[k];
		}
		
		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO
		
		for (l=0; l<tamCurso; j++, l++){	//LOOP PARA ALOCAR O CURSO NO BLOCO
			v[j] = reg[i].curso[l];
		}

		
		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO
		
		for (m=0; m<tamAno; j++, m++){		//LOOP PARA ALOCAR O ANO DE INGRESSO NO BLOCO
			v[j] = reg[i].ano[m];

		}
		
		v[j++] = (char) 13;					//DIVISAO DE CAMPOS DO REGISTRO

		tamVetor = j;						//SALVA O TAMANHO DO BLOCO NO tamVetor
		
		for (p=0; p<j;p++){
			cout<< v[p];
		}
		
		v[++j] = (char) 10;					//DIVISAO DE REGISTROS DO BLOCO 
		cout << endl;			

		}
	}

//Lembra da leitura do tamanho do bloco : fazer unsigned char para converter de sei la o q pra sei la o q 

	//Tamanho do vetor, dividindo por 256 e colocando o quociente na penultima posicao do vetor e o resto na ultima
	s = (int(j/256));
	r = (j%256);
	v[510]=r;
	v[511]=s;
	
	dat.write(v,512);					//ESCREVE O VETOR NO ARQUIVO
	
	/* o processo de pesquisa � pegar o tamanho do bloco e a partir dele
	traz�-lo para a mem�ria principal somente os registros e com isso 
	evitar lixo. Depois teria fazer uma pesquisa dentro desse vetor com os 
	registros na mem�ria principal, se encontrar o registro procurado, exibir
	na tela.*/
	
	FILE *ptFile;
	ptFile = fopen ( (arq + ".dat").c_str() , "r+b" );
	string linha;


	cin >> pesquisa;
	

	while (pesquisa != "0") {
		
		while(fread(&v[0],sizeof(char),TAM,ptFile)){
			
			if (linha.find(pesquisa,0) != string::npos)
			cout << endl;
		};
		
		cin >> pesquisa;		
}



	return 0;
}
